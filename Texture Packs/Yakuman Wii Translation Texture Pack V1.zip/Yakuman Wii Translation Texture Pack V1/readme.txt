To use texture pack, place the WAQJ01 folder into your Dolphin Load Textures folder.

To find where this folder is, open up Config in Dolphin, go to the Paths tab, and the folder location will be in the Load box at the bottom.
If your settings are the default, the end result after you move the folder should look like "Dolphin Emulator/Load/Textures/WAGJ01"

Then to turn on texture replacement after you move the folder, open up Graphics settings in Dolphin, go to the Advanced tab, and turn on
Load Custom Textures in the Utility Subheading.